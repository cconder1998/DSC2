﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DSC2.Models
{
    public class Box1
    {
        public string Product { get; set; }
        public string Price { get; set; }
    }
}
